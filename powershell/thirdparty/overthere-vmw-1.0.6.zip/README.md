# Project "overthere"
Runs something on a remote machine, i.e. over there.

